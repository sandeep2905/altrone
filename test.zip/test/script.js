
let cartCount = 0;

// Load products from JSON
$(document).ready(function () {

  $.getJSON('products.json', function (data) {
    renderProducts(data);
    //console.log('Products loaded');
  });

  // Add to cart
  // $(document).on('click', '.add-to-cart', function () {
  //   cartCount++;
  //   $('#cart-count').text(cartCount);
  // });

  let addedProducts = new Set();

  $(document).on('click', '.add-to-cart', function () {
    const productId = $(this).data('product-id');
    
    if (addedProducts.has(productId)) {
      alert('This product is already in the cart.');
      return;
    }

    // Add product to cart
    addedProducts.add(productId);
    cartCount++;
    $('#cart-count').text(cartCount);

    // Optional: Disable the button
    $(this).prop('disabled', true).text('Added');
  });


  // Remove product
  $(document).on('click', '.remove-product', function () {
    $(this).closest('.col-md-4').remove();
  });

  // Search functionality
  $('#search-bar').on('keyup', function () {
    const query = $(this).val().toLowerCase();
    let visibleCount = 0;

    $('.product-card').each(function () {
      const name = $(this).data('name').toLowerCase();
      const isMatch = name.includes(query);
      $(this).closest('.col-md-4').toggle(isMatch);
      if (isMatch) visibleCount++;
    });

    // Show/hide No products found
    if (visibleCount === 0) {
      $('#no-results').show();
    } else {
      $('#no-results').hide();
    }
  });


  // Modal for product details
  $(document).on('click', '.product-image', function () {
    const title = $(this).data('title');
    const image = $(this).attr('src');
    const description = $(this).data('description');

    $('#modalTitle').text(title);
    $('#modalImage').attr('src', image).attr('alt', title);
    $('#modalDescription').text(description);
    $('#productModal').modal('show');
  });
});

// Render products
function renderProducts(products) {
  const grid = $('#product-grid');
  products.forEach(product => {
    const card = `
      <div class="col-md-4 mb-4">
        <div class="card product-card" data-name="${product.name}">
          <img src="${product.image}" class="card-img-top product-image" alt="${product.name}" 
            data-title="${product.name}" data-description="${product.description}">
          <div class="card-body">
            <h5 class="card-title">${product.name}</h5>
            <p class="card-text">$${product.price.toFixed(2)}</p>
            <button class="btn btn-primary add-to-cart" data-product-id="${product.id}">Add to Cart</button>
            <button class="btn btn-outline-danger btn-sm float-end remove-product">Remove</button>
          </div>
        </div>
      </div>`;
    grid.append(card);
  });
}

